/*=========================================================*/
/* race.c --- for playing with ECE437 */
/*=========================================================*/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <semaphore.h>

typedef struct
{
  int balance[2];
} bnk;
bnk bank = {{100,100}};
bnk* Bank = &bank;
// global variable defined

//Mutex pointer for semaphore lock.
sem_t* mutex;

void *MakeTransactions()
{ // routine for thread execution
  int i, j, tmp1, tmp2, rint;
  double dummy;
  for (i = 0; i < 100; i++)
  {
    rint = (rand() % 30) - 15;
    //Wait on other processes before accessing balance. 
    sem_wait(mutex);
    if (((tmp1 = (*Bank).balance[0]) + rint) >= 0 && ((tmp2 = (*Bank).balance[1]) - rint) >= 0)
    {
      (*Bank).balance[0] = tmp1 + rint;
      for (j = 0; j < rint * 1000; j++)
      {
        dummy = 2.345 * 8.765 / 1.234;
      } // spend time on purpose
      (*Bank).balance[1] = tmp2 - rint;
    }
    //Done acessing balance
    sem_post(mutex);
  }
  return NULL;
}
int main(int argc, char **argv)
{
  int i;
  void *voidptr = NULL;
  //Shared memory for Bank struct.
  key_t key = ftok("race.c", 7);
  int shmid = shmget(key, sizeof(bank), IPC_CREAT | 0666);
  bnk* shm = (bnk*) shmat(shmid, NULL, 0);
  bnk* b = shm;
  //Copy initial balance and reassign global struct pointer.
  (*b).balance[0] = (*Bank).balance[0];
  (*b).balance[1] = (*Bank).balance[1];
  Bank = b;
  //Setup semaphore shared memory and initialize semaphore.
  key_t keyS = ftok("race.c", 20);
  int shmidS = shmget(keyS, sizeof(sem_t), IPC_CREAT | 0666);
  sem_t* mtx = (sem_t*) shmat(shmidS, NULL, 0);
  mutex = mtx;
  sem_init(mutex, 1, 1);

  printf("Init balances A:%d + B:%d ==> %d!\n",
         (*Bank).balance[0], (*Bank).balance[1], (*Bank).balance[0] + (*Bank).balance[1]);

  
  srand(getpid());
  pid_t pid = fork();
  if(pid == 0){
    MakeTransactions();
    exit(0);
  }
  else{
    MakeTransactions();
  }
  waitpid(pid, NULL, 0);
  
  printf("Let's check the balances A:%d + B:%d ==> %d ?= 200\n",
         (*Bank).balance[0], (*Bank).balance[1], (*Bank).balance[0] + (*Bank).balance[1]);
  return 0;
}