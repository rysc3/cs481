/*=========================================================*/
/* race.c --- for playing with ECE437 */
/*=========================================================*/
#include <unistd.h>
#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/ipc.h>
#include <sys/shm.h>
#include <sys/types.h>
#include <sys/wait.h>

typedef struct
{
  int balance[2];
} bnk;
bnk bank = {{100,100}};
bnk* Bank = &bank;
// global variable defined

void *MakeTransactions()
{ // routine for thread execution
  int i, j, tmp1, tmp2, rint;
  double dummy;
  for (i = 0; i < 100; i++)
  {
    rint = (rand() % 30) - 15;
    if (((tmp1 = (*Bank).balance[0]) + rint) >= 0 && ((tmp2 = (*Bank).balance[1]) - rint) >= 0)
    {
      (*Bank).balance[0] = tmp1 + rint;
      for (j = 0; j < rint * 1000; j++)
      {
        dummy = 2.345 * 8.765 / 1.234;
      } // spend time on purpose
      (*Bank).balance[1] = tmp2 - rint;
    }
  }
  return NULL;
}
int main(int argc, char **argv)
{
  int i;
  void *voidptr = NULL;
  pthread_t tid[2];
  key_t key = ftok("race.c", 7);
  int shmid = shmget(key, sizeof(bank), IPC_CREAT | 0666);
  bnk* shm = (bnk*) shmat(shmid, NULL, 0);
  bnk* b = shm;
  (*b).balance[0] = (*Bank).balance[0];
  (*b).balance[1] = (*Bank).balance[1];
  Bank = b;
   printf("Init balances A:%d + B:%d ==> %d!\n",
         (*Bank).balance[0], (*Bank).balance[1], (*Bank).balance[0] + (*Bank).balance[1]);

  srand(getpid());
  pid_t pid = fork();
  if(pid == 0){
    MakeTransactions();
    exit(0);
  }
  else{
    MakeTransactions();
  }
  waitpid(pid, NULL, 0);
  
  printf("Let's check the balances A:%d + B:%d ==> %d ?= 200\n",
         (*Bank).balance[0], (*Bank).balance[1], (*Bank).balance[0] + (*Bank).balance[1]);
  return 0;
}